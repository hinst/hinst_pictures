package revel

const (
	// Current Revel version
	VERSION    = "0.12.0"
	// Latest commit date
	BUILD_DATE = "2015-03-25"
	// Minimum required Go version
	MINIMUM_GO = ">= go1.3"
)
