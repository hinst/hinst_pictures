modules
=======

Set of officially supported modules for Revel applications

### Caution
this is a work in progress