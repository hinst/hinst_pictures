Sqlite Auth driver
==================

