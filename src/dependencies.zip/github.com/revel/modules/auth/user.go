package auth

// var storageDriver auth.StorageDriver // postgres in example

// type AuthUserModel struct {
// 	userId   string
// 	security *SecurityDriver // bcrypt in example

// }

// func (self *AuthUserModel) UserId() string {
// 	return self.userId
// }

// func (self *AuthUserModel) Secret() string {
// 	return self.security.Secret()
// }
