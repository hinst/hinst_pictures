# Revel command line tools

Provides the `revel` command, used to create and run Revel apps.

- More info at http://revel.github.io/manual/tool.html

Install
------------
```bash
go get github.com/revel/cmd/revel
```
