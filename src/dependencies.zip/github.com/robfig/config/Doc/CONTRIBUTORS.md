###### Notice

*This is the official list of people who can contribute (and typically have
contributed) code to the **config** repository.*

*The AUTHORS file lists the copyright holders; this file lists people. For
example, the employees of an organization are listed here but not in AUTHORS,
because the organization holds the copyright.*

*Names should be added to this file as: `[Name](web address)` or `Name <email>`*

*Please keep the list sorted.*

* * *

### Initial author

[Miguel Branco](https://github.com/msbranco)

### Maintainer

[Rob Figueiredo](https://github.com/robfig)

### Other authors

[Jonas mg](https://github.com/kless)
[Tom Bruggeman](https://github.com/tmbrggmn)

